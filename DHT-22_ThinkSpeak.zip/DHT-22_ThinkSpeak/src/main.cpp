#include <Wire.h>
#include <Arduino.h>
#include "DHT.h"
#include "ThingSpeak.h"
#include <ESP8266WiFi.h>
#define DHTPIN 4 // IMPORTANT D2 on NodeMCU is GPIO 4

#define DHTTYPE DHT22


const char * ssid = "wifiuserid";
const char * password = "wifipassword";

unsigned long myChannelnumber = 1084965;
const char * writeAPIkey = "PNJO669G73X1SFVD";
const char * server = "api.thingspeak.com";

WiFiClient client;

DHT dht(DHTPIN,DHTTYPE);


void updateThingSpeak(float t, float h){

  ThingSpeak.setField(1,t);
  ThingSpeak.setField(2,h);
  ThingSpeak.writeFields(myChannelnumber,writeAPIkey);
  delay(20 * 1000);
}

void setup() {
  // put your setup code here, to run once:
  delay(1000);
  Serial.begin(115200);
  dht.begin();
  ThingSpeak.begin(client);
  WiFi.begin(ssid,password);
  Serial.print("Connecting ....");
  while (WiFi.status() != WL_CONNECTED){
    delay(500);
    Serial.print("Waiting for the wifi ....");
  }
  Serial.println("Wifi Connected To :");
  Serial.print(WiFi.localIP());
  
}

void loop() {
  // put your main code here, to run repeatedly:
  delay(2000);
  float humidity = dht.readHumidity();    // this value is going to be in percentage.
  float temperature = dht.readTemperature();  // this is in Celcius
  float temperature_faren = dht.readTemperature(true); // this is in Farenheit

  // checking for any kinds of failures in the code.
  // here isnan states -> "is not a number"
  if(isnan(humidity) || isnan(temperature) || isnan(temperature_faren)){

    Serial.println("Failed to Read From DHT-22!");
    return;
  }

  // Compute Heat index in farenheit
  float heatIndexFaren = dht.computeHeatIndex(temperature_faren,humidity,true);
  
  // Compute Heat index in Celcius

  float heatIndex = dht.computeHeatIndex(temperature,humidity,false);

  Serial.printf("Humidity : %f\n",humidity);
  Serial.printf("Temperature *C : %f\n",temperature);
  Serial.printf("Temperature *F : %f\n",temperature_faren);
  Serial.printf("Heat Index *C : %f\n",heatIndex);
  Serial.printf("Heat Index *F : %f\n",heatIndexFaren);

  if(client.connect(server,80)){
    updateThingSpeak(temperature,humidity);
  }

}